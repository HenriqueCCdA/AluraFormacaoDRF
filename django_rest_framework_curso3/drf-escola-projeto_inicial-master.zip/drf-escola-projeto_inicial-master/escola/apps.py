from django.apps import AppConfig


class EscolaConfig(AppConfig):
    name = 'escola'
